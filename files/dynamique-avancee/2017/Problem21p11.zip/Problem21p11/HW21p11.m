function [t,VAR,Output] = HW21p11( kpA, kpB, kdA, kdB )
narginchk( 4, 4 );    % Check proper minimum/maximum number of arguments.
%===========================================================================
% File: HW21p11.m created on Thu Aug  3 2017 by MotionGenesis 5.7.
% Advanced Student Licensee: AlexisLussierDesbiens (until May 2018).
% Portions copyright (c) 2009-2015 Motion Genesis LLC.  Rights reserved.
% Paid-up MotionGenesis Advanced Student licensees are granted the right
% right to distribute this code for legal student-academic (non-professional) purposes only,
% provided this copyright notice appears in all copies and distributions.
%===========================================================================
% The software is provided "as is", without warranty of any kind, express or    
% implied, including but not limited to the warranties of merchantability or    
% fitness for a particular purpose. In no event shall the authors, contributors,
% or copyright holders be liable for any claim, damages or other liability,     
% whether in an action of contract, tort, or otherwise, arising from, out of, or
% in connection with the software or the use or other dealings in the software. 
%===========================================================================
eventDetectedByIntegratorTerminate1OrContinue0 = [];
IE=0; wx=0; wz=0; qCp=0; WorkAp=0; WorkBp=0; wyp=0; qApp=0; qBpp=0; qAdesired=0; qBdesired=0; TA=0; TB=0; qAdesiredp=0; qBdesiredp=0; Ke=0; KeMinusWorkAB=0; xE=0; zE=0;


%-------------------------------+--------------------------+-------------------+-----------------
% Quantity                      | Value                    | Units             | Description
%-------------------------------|--------------------------|-------------------|-----------------
LB                              =  0.8;                    % m                   Constant
LC                              =  1.2;                    % m                   Constant
mE                              =  50;                     % kg                  Constant
mH                              =  800;                    % kg                  Constant
qB0                             =  20;                     % deg                 Constant
qBF                             =  60;                     % deg                 Constant
r                               =  0.4;                    % m                   Constant
tF                              =  16;                     % sec                 Constant

qA                              =  0;                      % deg                 Initial Value
qB                              =  20;                     % deg                 Initial Value
qC                              =  3.517118987743595;      % deg                 Initial Value
WorkA                           =  0;                      % J                   Initial Value
WorkB                           =  0;                      % J                   Initial Value
wy                              =  0;                      % UNITS               Initial Value
qAp                             =  0;                      % deg/sec             Initial Value
qBp                             =  0;                      % deg/sec             Initial Value

tInitial                        =  0.0;                    % second              Initial Time
tFinal                          =  25;                     % sec                 Final Time
tStep                           =  0.1;                    % second              Integration Step
printIntScreen                  =  1;                      % 0 or +integer       0 is NO screen output
printIntFile                    =  1;                      % 0 or +integer       0 is NO file   output
absError                        =  1.0E-05;                %                     Absolute Error
relError                        =  1.0E-08;                %                     Relative Error
%-------------------------------+--------------------------+-------------------+-----------------

% Unit conversions
DEGtoRAD = pi / 180.0;
RADtoDEG = 180.0 / pi;
qB0 = qB0 * DEGtoRAD;
qBF = qBF * DEGtoRAD;
qA = qA * DEGtoRAD;
qB = qB * DEGtoRAD;
qC = qC * DEGtoRAD;
qAp = qAp * DEGtoRAD;
qBp = qBp * DEGtoRAD;

% Evaluate constants
IE = 0.4*mE*r^2;


VAR = SetMatrixFromNamedQuantities;
[t,VAR,Output] = IntegrateForwardOrBackward( tInitial, tFinal, tStep, absError, relError, VAR, printIntScreen, printIntFile );
OutputToScreenOrFile( [], 0, 0 );   % Close output files



%===========================================================================
function sys = mdlDerivatives( t, VAR, uSimulink )
%===========================================================================
SetNamedQuantitiesFromMatrix( VAR );
qCp = LB*cos(qB)*qBp/(LC*cos(qC));
wx = -(LB*cos(qB)+LC*cos(qC))*qAp/r;
wz = LB*(sin(qB)+cos(qB)*tan(qC))*qBp/r;

% Quantities previously specified in MotionGenesis.
qAdesired = 6.283185307179586*t/tF;
qAdesiredp = 6.283185307179586/tF;
TA = kpA*(qAdesired-qA) + kdA*(qAdesiredp-qAp);
qBdesired = qB0 + 0.1591549430918953*(qB0-qBF)*sin(6.283185307179586*t/tF) - (qB0-qBF)*t/tF;
qBdesiredp = (qB0-qBF)*(-1+cos(6.283185307179586*t/tF))/tF;
TB = kpB*(qBdesired-qB) + kdB*(qBdesiredp-qBp);

WorkAp = TA*qAp;
WorkBp = TB*qBp;

COEF = zeros(3,3);
COEF(1,1) = mE*(LB*cos(qB)+LC*cos(qC))^2 + mH*(LB*cos(qB)+LC*cos(qC))^2 + IE*(1+(LB*cos(qB)+LC*cos(qC))^2/r^2);
COEF(1,3) = IE;
COEF(2,2) = LB^2*(IE*(sin(qB)+cos(qB)*tan(qC))^2/r^2+mE*(1+cos(qB)^2/cos(qC)^2-2*cos(qB)*cos(qB+qC)/cos(qC))+mH*(1+cos(qB)^2/cos(qC)^2-2*cos(qB)*cos(qB+qC)/cos(qC)));
COEF(3,1) = 1;
COEF(3,3) = 1;
RHS = zeros(1,3);
RHS(1) = TA + (LB*cos(qB)+LC*cos(qC))*qAp*(2*mE*(LB*sin(qB)*qBp+LC*sin(qC)*qCp)+2*mH*(LB*sin(qB)*qBp+LC*sin(qC)*qCp)+IE*(wz+(LB*sin(qB)*qBp+LC*sin(qC)*qCp)/r)/r);
RHS(2) = TB + LB*(IE*(sin(qB)+cos(qB)*tan(qC))*(wx*qAp-(LB*cos(qB)*qBp^2+LC*cos(qC)*qCp^2-tan(qC)*(LB*sin(qB)*qBp^2-LC*sin(qC)*qCp^2))/r)/r-mE*(sin(qB)*(LB*cos(qB)+LC*cos(qC))*qAp^2+cos(qB)*tan(qC)*(LB*cos(qB)+LC*cos(qC))*qAp^2+LC*sin(  ...
qB+qC)*qCp^2+(cos(qB+qC)*(LB*sin(qB)*qBp^2-LC*sin(qC)*qCp^2)+cos(qB)*(LB*sin(qB+qC)*qBp^2-(LB*sin(qB)*qBp^2-LC*sin(qC)*qCp^2)/cos(qC)))/cos(qC))-mH*(sin(qB)*(LB*cos(qB)+LC*cos(qC))*qAp^2+cos(qB)*tan(qC)*(LB*cos(qB)+LC*cos(qC))*qAp^2+LC*  ...
sin(qB+qC)*qCp^2+(cos(qB+qC)*(LB*sin(qB)*qBp^2-LC*sin(qC)*qCp^2)+cos(qB)*(LB*sin(qB+qC)*qBp^2-(LB*sin(qB)*qBp^2-LC*sin(qC)*qCp^2)/cos(qC)))/cos(qC)));
SolutionToAlgebraicEquations = COEF \ transpose(RHS);

% Update variables after uncoupling equations
qApp = SolutionToAlgebraicEquations(1);
qBpp = SolutionToAlgebraicEquations(2);
wyp = SolutionToAlgebraicEquations(3);

sys = transpose( SetMatrixOfDerivativesPriorToIntegrationStep );
end



%===========================================================================
function VAR = SetMatrixFromNamedQuantities
%===========================================================================
VAR = zeros(1,8);
VAR(1) = qA;
VAR(2) = qB;
VAR(3) = qC;
VAR(4) = WorkA;
VAR(5) = WorkB;
VAR(6) = wy;
VAR(7) = qAp;
VAR(8) = qBp;
end


%===========================================================================
function SetNamedQuantitiesFromMatrix( VAR )
%===========================================================================
qA = VAR(1);
qB = VAR(2);
qC = VAR(3);
WorkA = VAR(4);
WorkB = VAR(5);
wy = VAR(6);
qAp = VAR(7);
qBp = VAR(8);
end


%===========================================================================
function VARp = SetMatrixOfDerivativesPriorToIntegrationStep
%===========================================================================
VARp = zeros(1,8);
VARp(1) = qAp;
VARp(2) = qBp;
VARp(3) = qCp;
VARp(4) = WorkAp;
VARp(5) = WorkBp;
VARp(6) = wyp;
VARp(7) = qApp;
VARp(8) = qBpp;
end



%===========================================================================
function Output = mdlOutputs( t, VAR, uSimulink )
%===========================================================================
xE = cos(qA)*(LB*cos(qB)+LC*cos(qC));
zE = -sin(qA)*(LB*cos(qB)+LC*cos(qC));
Ke = 0.5*IE*(wx^2+wz^2+(qAp+wy)^2) + 0.5*mE*(LB^2*qBp^2+(LB*cos(qB)+LC*cos(qC))^2*qAp^2+LC^2*qCp^2-2*LB*LC*cos(qB+qC)*qBp*qCp) + 0.5*mH*(LB^2*qBp^2+(LB*cos(qB)+LC*cos(qC))^2*qAp^2+LC^2*qCp^2-2*LB*LC*cos(qB+qC)*qBp*qCp);
KeMinusWorkAB = Ke - WorkA - WorkB;

Output = zeros(1,3);
Output(1) = xE;
Output(2) = zE;
Output(3) = KeMinusWorkAB;
end


%===========================================================================
function OutputToScreenOrFile( Output, shouldPrintToScreen, shouldPrintToFile )
%===========================================================================
persistent FileIdentifier hasHeaderInformationBeenWritten;

if( isempty(Output) ),
   if( ~isempty(FileIdentifier) ),
      fclose( FileIdentifier(1) );
      clear FileIdentifier;
      fprintf( 1, '\n Output is in the file HW21p11.1\n' );
      fprintf( 1, '\n Note: Plots are automatically generated by issuing the OutputPlot command in MotionGenesis\n' );
      fprintf( 1, '\n To load and plot columns 1 and 2 with a solid line and columns 1 and 3 with a dashed line, enter:\n' );
      fprintf( 1, '    someName = load( ''HW21p11.1'' );\n' );
      fprintf( 1, '    plot( someName(:,1), someName(:,2), ''-'', someName(:,1), someName(:,3), ''--'' )\n\n' );
   end
   clear hasHeaderInformationBeenWritten;
   return;
end

if( isempty(hasHeaderInformationBeenWritten) ),
   if( shouldPrintToScreen ),
      fprintf( 1,                '%%      xE             zE        KeMinusWorkAB\n' );
      fprintf( 1,                '%%      (m)            (m)            (J)\n\n' );
   end
   if( shouldPrintToFile && isempty(FileIdentifier) ),
      FileIdentifier(1) = fopen('HW21p11.1', 'wt');   if( FileIdentifier(1) == -1 ), error('Error: unable to open file HW21p11.1'); end
      fprintf(FileIdentifier(1), '%% FILE: HW21p11.1\n%%\n' );
      fprintf(FileIdentifier(1), '%%      xE             zE        KeMinusWorkAB\n' );
      fprintf(FileIdentifier(1), '%%      (m)            (m)            (J)\n\n' );
   end
   hasHeaderInformationBeenWritten = 1;
end

if( shouldPrintToScreen ), WriteNumericalData( 1,                 Output(1:3) );  end
if( shouldPrintToFile ),   WriteNumericalData( FileIdentifier(1), Output(1:3) );  end
end


%===========================================================================
function WriteNumericalData( fileIdentifier, Output )
%===========================================================================
numberOfOutputQuantities = length( Output );
if( numberOfOutputQuantities > 0 ),
   for( i = 1 : numberOfOutputQuantities ),
      fprintf( fileIdentifier, ' %- 14.6E', Output(i) );
   end
   fprintf( fileIdentifier, '\n' );
end
end



%===========================================================================
function [functionsToEvaluateForEvent, eventTerminatesIntegration1Otherwise0ToContinue, eventDirection_AscendingIs1_CrossingIs0_DescendingIsNegative1] = EventDetection( t, VAR, uSimulink )
%===========================================================================
% Detects when designated functions are zero or cross zero with positive or negative slope.
% Step 1: Uncomment call to mdlDerivatives and mdlOutputs.
% Step 2: Change functionsToEvaluateForEvent,                      e.g., change  []  to  [t - 5.67]  to stop at t = 5.67.
% Step 3: Change eventTerminatesIntegration1Otherwise0ToContinue,  e.g., change  []  to  [1]  to stop integrating.
% Step 4: Change eventDirection_AscendingIs1_CrossingIs0_DescendingIsNegative1,  e.g., change  []  to  [1].
% Step 5: Possibly modify function EventDetectedByIntegrator (if eventTerminatesIntegration1Otherwise0ToContinue is 0).
%---------------------------------------------------------------------------
% mdlDerivatives( t, VAR, uSimulink );        % UNCOMMENT FOR EVENT HANDLING
% mdlOutputs(     t, VAR, uSimulink );        % UNCOMMENT FOR EVENT HANDLING
functionsToEvaluateForEvent = [];
eventTerminatesIntegration1Otherwise0ToContinue = [];
eventDirection_AscendingIs1_CrossingIs0_DescendingIsNegative1 = [];
eventDetectedByIntegratorTerminate1OrContinue0 = eventTerminatesIntegration1Otherwise0ToContinue;
end


%===========================================================================
function [isIntegrationFinished, VAR] = EventDetectedByIntegrator( t, VAR, nIndexOfEvents )
%===========================================================================
isIntegrationFinished = eventDetectedByIntegratorTerminate1OrContinue0( nIndexOfEvents );
if( ~isIntegrationFinished ),
   SetNamedQuantitiesFromMatrix( VAR );
%  Put code here to modify how integration continues.
   VAR = SetMatrixFromNamedQuantities;
end
end



%===========================================================================
function [t,VAR,Output] = IntegrateForwardOrBackward( tInitial, tFinal, tStep, absError, relError, VAR, printIntScreen, printIntFile )
%===========================================================================
OdeMatlabOptions = odeset( 'RelTol',relError, 'AbsTol',absError, 'MaxStep',tStep, 'Events',@EventDetection );
t = tInitial;                 epsilonT = 0.001*tStep;                   tFinalMinusEpsilonT = tFinal - epsilonT;
printCounterScreen = 0;       integrateForward = tFinal >= tInitial;    tAtEndOfIntegrationStep = t + tStep;
printCounterFile   = 0;       isIntegrationFinished = 0;
mdlDerivatives( t, VAR, 0 );
while 1,
   if( (integrateForward && t >= tFinalMinusEpsilonT) || (~integrateForward && t <= tFinalMinusEpsilonT) ), isIntegrationFinished = 1;  end
   shouldPrintToScreen = printIntScreen && ( isIntegrationFinished || printCounterScreen <= 0.01 );
   shouldPrintToFile   = printIntFile   && ( isIntegrationFinished || printCounterFile   <= 0.01 );
   if( isIntegrationFinished || shouldPrintToScreen || shouldPrintToFile ),
      Output = mdlOutputs( t, VAR, 0 );
      OutputToScreenOrFile( Output, shouldPrintToScreen, shouldPrintToFile );
      if( isIntegrationFinished ), break;  end
      if( shouldPrintToScreen ), printCounterScreen = printIntScreen;  end
      if( shouldPrintToFile ),   printCounterFile   = printIntFile;    end
   end
   [TimeOdeArray, VarOdeArray, timeEventOccurredInIntegrationStep, nStatesArraysAtEvent, nIndexOfEvents] = ode45( @mdlDerivatives, [t tAtEndOfIntegrationStep], VAR, OdeMatlabOptions, 0 );
   if( isempty(timeEventOccurredInIntegrationStep) ),
      t = TimeOdeArray( length(TimeOdeArray) );
      VAR = VarOdeArray( length(TimeOdeArray), : );
      printCounterScreen = printCounterScreen - 1;
      printCounterFile   = printCounterFile   - 1;
      if( abs(tAtEndOfIntegrationStep - t) >= abs(epsilonT) ), warning('numerical integration failed'); break;  end
      tAtEndOfIntegrationStep = t + tStep;
   else
      t = timeEventOccurredInIntegrationStep;
      VAR = nStatesArraysAtEvent;
      printCounterScreen = 0;
      printCounterFile   = 0;
      [isIntegrationFinished, VAR] = EventDetectedByIntegrator( t, VAR, nIndexOfEvents );
   end
end
end


%================================
end    % End of function HW21p11
%================================
