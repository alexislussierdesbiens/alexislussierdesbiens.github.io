clear all;

% Quelques combinaisons de gains intéressantes... 
HW21p11(3000,3000,300,300)
% HW21p11(30,30,300,300)
% HW21p11(3000,3000,30,30)
% HW21p11(6000,6000,30,30)

data = load('HW21p11.1'); 

xe = data(:,1); 
ze = data(:,2);
KeMinusWorkAB = data(:,3); 

figure(3)
subplot(211)
plot(xe, ze)
xlabel('xe (m)')
ylabel('ze (m)')
axis equal
grid on
hold on

subplot(212)
plot(KeMinusWorkAB)
xlabel('timestep')
ylabel('KeMinusWorkAB (J)')
hold on
