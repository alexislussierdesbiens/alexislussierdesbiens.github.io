function [t,VAR,Output] = Babyboot(mA, Filename)
%===========================================================================
% File: Babyboot.m created on Thu Jun 15 2017 by MotionGenesis 5.7.
% Advanced Student Licensee: AlexisLussierDesbiens (until May 2018).
% Portions copyright (c) 2009-2015 Motion Genesis LLC.  Rights reserved.
% Paid-up MotionGenesis Advanced Student licensees are granted the right
% right to distribute this code for legal student-academic (non-professional) purposes only,
% provided this copyright notice appears in all copies and distributions.
%===========================================================================
% The software is provided "as is", without warranty of any kind, express or    
% implied, including but not limited to the warranties of merchantability or    
% fitness for a particular purpose. In no event shall the authors, contributors,
% or copyright holders be liable for any claim, damages or other liability,     
% whether in an action of contract, tort, or otherwise, arising from, out of, or
% in connection with the software or the use or other dealings in the software. 
%===========================================================================
eventDetectedByIntegratorTerminate1OrContinue0 = [];
qApp=0; qBpp=0; Energy=0; KE=0; nyBcm=0; nzBcm=0; PE=0;


%-------------------------------+--------------------------+-------------------+-----------------
% Quantity                      | Value                    | Units             | Description
%-------------------------------|--------------------------|-------------------|-----------------
IAx                             =  50;                     % g*cm^2              Constant
IBx                             =  2500;                   % g*cm^2              Constant
IBy                             =  500;                    % g*cm^2              Constant
IBz                             =  2000;                   % g*cm^2              Constant
LA                              =  7.5;                    % cm                  Constant
LB                              =  20;                     % cm                  Constant
% mA                              =  10;                     % grams               Constant
mB                              =  100;                    % grams               Constant

qA                              =  158;                     % deg                 Initial Value
qB                              =  1;                      % deg                 Initial Value
qAp                             =  0.0;                    % rad/sec             Initial Value
qBp                             =  0.0;                    % rad/sec             Initial Value

tInitial                        =  0.0;                    % second              Initial Time
tFinal                          =  0.01;                     % sec                 Final Time
tStep                           =  0.02;                   % sec                 Integration Step
printIntScreen                  =  1;                      % 0 or +integer       0 is NO screen output
printIntFile                    =  1;                      % 0 or +integer       0 is NO file   output
absError                        =  1.0E-07;                %                     Absolute Error
relError                        =  1.0E-07;                %                     Relative Error
%-------------------------------+--------------------------+-------------------+-----------------

% Unit conversions.  UnitSystem: kilogram, meter, second
DEGtoRAD = pi / 180.0;
RADtoDEG = 180.0 / pi;
IAx = IAx * 1.0E-7;
IBx = IBx * 1.0E-7;
IBy = IBy * 1.0E-7;
IBz = IBz * 1.0E-7;
LA = LA * 0.01;
LB = LB * 0.01;
mA = mA * 0.001;
mB = mB * 0.001;
qA = qA * DEGtoRAD;
qB = qB * DEGtoRAD;

VAR = SetMatrixFromNamedQuantities;
[t,VAR,Output] = IntegrateForwardOrBackward( tInitial, tFinal, tStep, absError, relError, VAR, printIntScreen, printIntFile );
OutputToScreenOrFile( [], 0, 0 );   % Close output files
PlotOutputFiles;


%===========================================================================
function sys = mdlDerivatives( t, VAR, uSimulink )
%===========================================================================
SetNamedQuantitiesFromMatrix( VAR );
TA = 0.3*sin(2*t); 
qApp = -2*(4.905*(mA*LA+mB*LB)*sin(qA)-(IBx-IBy)*sin(qB)*cos(qB)*qAp*qBp)/(IAx+mA*LA^2+mB*LB^2+IBx*cos(qB)^2+IBy*sin(qB)^2);
qBpp = -(IBx-IBy)*sin(qB)*cos(qB)*qAp^2/IBz;

sys = transpose( SetMatrixOfDerivativesPriorToIntegrationStep );
end



%===========================================================================
function VAR = SetMatrixFromNamedQuantities
%===========================================================================
VAR = zeros(1,4);
VAR(1) = qA;
VAR(2) = qB;
VAR(3) = qAp;
VAR(4) = qBp;
end


%===========================================================================
function SetNamedQuantitiesFromMatrix( VAR )
%===========================================================================
qA = VAR(1);
qB = VAR(2);
qAp = VAR(3);
qBp = VAR(4);
end


%===========================================================================
function VARp = SetMatrixOfDerivativesPriorToIntegrationStep
%===========================================================================
VARp = zeros(1,4);
VARp(1) = qAp;
VARp(2) = qBp;
VARp(3) = qApp;
VARp(4) = qBpp;
end



%===========================================================================
function Output = mdlOutputs( t, VAR, uSimulink )
%===========================================================================
KE = 0.5*IAx*qAp^2 + 0.5*IBx*qAp^2 + 0.5*IBz*qBp^2 + 0.5*mA*LA^2*qAp^2 + 0.5*mB*LB^2*qAp^2 - 0.5*(IBx-IBy)*sin(qB)^2*qAp^2;
PE = -9.81*(mA*LA+mB*LB)*cos(qA);
Energy = PE + KE;
nzBcm = -LB*cos(qA);
nyBcm = LB*sin(qA);

Output = zeros(1,6);
Output(1) = t;
Output(2) = qB*RADtoDEG;

Output(3) = t;
Output(4) = Energy;

Output(5) = nzBcm;
Output(6) = nyBcm;
end


%===========================================================================
function OutputToScreenOrFile( Output, shouldPrintToScreen, shouldPrintToFile )
%===========================================================================
persistent FileIdentifier hasHeaderInformationBeenWritten;

if( isempty(Output) ),
   if( ~isempty(FileIdentifier) ),
      for( i = 1 : 3 ),  fclose( FileIdentifier(i) );  end
      clear FileIdentifier;
      fprintf( 1, '\n Output is in the files Babyboot.i  (i=1,2,3)\n\n' );
   end
   clear hasHeaderInformationBeenWritten;
   return;
end

if( isempty(hasHeaderInformationBeenWritten) ),
   if( shouldPrintToScreen ),
      fprintf( 1,                '%%       t             qB\n' );
      fprintf( 1,                '%%     (sec)          (deg)\n\n' );
   end
   if( shouldPrintToFile && isempty(FileIdentifier) ),
      FileIdentifier = zeros(1,3);
      FileIdentifier(1) = fopen([Filename,'.1'], 'wt');   if( FileIdentifier(1) == -1 ), error('Error: unable to open file Babyboot.1'); end
      fprintf(FileIdentifier(1), '%% FILE: Babyboot.1\n%%\n' );
      fprintf(FileIdentifier(1), '%%       t             qB\n' );
      fprintf(FileIdentifier(1), '%%     (sec)          (deg)\n\n' );
      FileIdentifier(2) = fopen('Babyboot.2', 'wt');   if( FileIdentifier(2) == -1 ), error('Error: unable to open file Babyboot.2'); end
      fprintf(FileIdentifier(2), '%% FILE: Babyboot.2\n%%\n' );
      fprintf(FileIdentifier(2), '%%       t           Energy\n' );
      fprintf(FileIdentifier(2), '%%     (sec)          (N*m)\n\n' );
      FileIdentifier(3) = fopen('Babyboot.3', 'wt');   if( FileIdentifier(3) == -1 ), error('Error: unable to open file Babyboot.3'); end
      fprintf(FileIdentifier(3), '%% FILE: Babyboot.3\n%%\n' );
      fprintf(FileIdentifier(3), '%%     nzBcm          nyBcm\n' );
      fprintf(FileIdentifier(3), '%%    (UNITS)        (UNITS)\n\n' );
   end
   hasHeaderInformationBeenWritten = 1;
end

if( shouldPrintToScreen ), WriteNumericalData( 1,                 Output(1:2) );  end
if( shouldPrintToFile ),   WriteNumericalData( FileIdentifier(1), Output(1:2) );  end
if( shouldPrintToFile ),   WriteNumericalData( FileIdentifier(2), Output(3:4) );  end
if( shouldPrintToFile ),   WriteNumericalData( FileIdentifier(3), Output(5:6) );  end
end


%===========================================================================
function WriteNumericalData( fileIdentifier, Output )
%===========================================================================
numberOfOutputQuantities = length( Output );
if( numberOfOutputQuantities > 0 ),
   for( i = 1 : numberOfOutputQuantities ),
      fprintf( fileIdentifier, ' %- 14.6E', Output(i) );
   end
   fprintf( fileIdentifier, '\n' );
end
end



%===========================================================================
function PlotOutputFiles
%===========================================================================
if( printIntFile == 0 ),  return;  end
figure(1);
data = load( 'Babyboot.1' ); 
plot( data(:,1),data(:,2),'-b', 'LineWidth',3 );
legend( 'qB (deg)' );
xlabel('t (sec)');   ylabel('qB (deg)');   % title('Some plot title');
clear data;

figure(2);
data = load( 'Babyboot.2' ); 
plot( data(:,1),data(:,2),'-b', 'LineWidth',3 );
legend( 'Energy (N*m)' );
xlabel('t (sec)');   ylabel('Energy (N*m)');   % title('Some plot title');
clear data;

figure(3);
data = load( 'Babyboot.3' ); 
plot( data(:,1),data(:,2),'-b', 'LineWidth',3 );
legend( 'nyBcm' );
xlabel('nzBcm ');   ylabel('nyBcm ');   % title('Some plot title');
clear data;
end



%===========================================================================
function [functionsToEvaluateForEvent, eventTerminatesIntegration1Otherwise0ToContinue, eventDirection_AscendingIs1_CrossingIs0_DescendingIsNegative1] = EventDetection( t, VAR, uSimulink )
%===========================================================================
% Detects when designated functions are zero or cross zero with positive or negative slope.
% Step 1: Uncomment call to mdlDerivatives and mdlOutputs.
% Step 2: Change functionsToEvaluateForEvent,                      e.g., change  []  to  [t - 5.67]  to stop at t = 5.67.
% Step 3: Change eventTerminatesIntegration1Otherwise0ToContinue,  e.g., change  []  to  [1]  to stop integrating.
% Step 4: Change eventDirection_AscendingIs1_CrossingIs0_DescendingIsNegative1,  e.g., change  []  to  [1].
% Step 5: Possibly modify function EventDetectedByIntegrator (if eventTerminatesIntegration1Otherwise0ToContinue is 0).
%---------------------------------------------------------------------------
% mdlDerivatives( t, VAR, uSimulink );        % UNCOMMENT FOR EVENT HANDLING
% mdlOutputs(     t, VAR, uSimulink );        % UNCOMMENT FOR EVENT HANDLING
functionsToEvaluateForEvent = [];
eventTerminatesIntegration1Otherwise0ToContinue = [];
eventDirection_AscendingIs1_CrossingIs0_DescendingIsNegative1 = [];
eventDetectedByIntegratorTerminate1OrContinue0 = eventTerminatesIntegration1Otherwise0ToContinue;
end


%===========================================================================
function [isIntegrationFinished, VAR] = EventDetectedByIntegrator( t, VAR, nIndexOfEvents )
%===========================================================================
isIntegrationFinished = eventDetectedByIntegratorTerminate1OrContinue0( nIndexOfEvents );
if( ~isIntegrationFinished ),
   SetNamedQuantitiesFromMatrix( VAR );
%  Put code here to modify how integration continues.
   VAR = SetMatrixFromNamedQuantities;
end
end



%===========================================================================
function [t,VAR,Output] = IntegrateForwardOrBackward( tInitial, tFinal, tStep, absError, relError, VAR, printIntScreen, printIntFile )
%===========================================================================
OdeMatlabOptions = odeset( 'RelTol',relError, 'AbsTol',absError, 'MaxStep',tStep, 'Events',@EventDetection );
t = tInitial;                 epsilonT = 0.001*tStep;                   tFinalMinusEpsilonT = tFinal - epsilonT;
printCounterScreen = 0;       integrateForward = tFinal >= tInitial;    tAtEndOfIntegrationStep = t + tStep;
printCounterFile   = 0;       isIntegrationFinished = 0;
mdlDerivatives( t, VAR, 0 );
while 1,
   if( (integrateForward && t >= tFinalMinusEpsilonT) || (~integrateForward && t <= tFinalMinusEpsilonT) ), isIntegrationFinished = 1;  end
   shouldPrintToScreen = printIntScreen && ( isIntegrationFinished || printCounterScreen <= 0.01 );
   shouldPrintToFile   = printIntFile   && ( isIntegrationFinished || printCounterFile   <= 0.01 );
   if( isIntegrationFinished || shouldPrintToScreen || shouldPrintToFile ),
      Output = mdlOutputs( t, VAR, 0 );
      OutputToScreenOrFile( Output, shouldPrintToScreen, shouldPrintToFile );
      if( isIntegrationFinished ), break;  end
      if( shouldPrintToScreen ), printCounterScreen = printIntScreen;  end
      if( shouldPrintToFile ),   printCounterFile   = printIntFile;    end
   end
   [TimeOdeArray, VarOdeArray, timeEventOccurredInIntegrationStep, nStatesArraysAtEvent, nIndexOfEvents] = ode45( @mdlDerivatives, [t tAtEndOfIntegrationStep], VAR, OdeMatlabOptions, 0 );
   if( isempty(timeEventOccurredInIntegrationStep) ),
      t = TimeOdeArray( length(TimeOdeArray) );
      VAR = VarOdeArray( length(TimeOdeArray), : );
      printCounterScreen = printCounterScreen - 1;
      printCounterFile   = printCounterFile   - 1;
      if( abs(tAtEndOfIntegrationStep - t) >= abs(epsilonT) ), warning('numerical integration failed'); break;  end
      tAtEndOfIntegrationStep = t + tStep;
   else
      t = timeEventOccurredInIntegrationStep;
      VAR = nStatesArraysAtEvent;
      printCounterScreen = 0;
      printCounterFile   = 0;
      [isIntegrationFinished, VAR] = EventDetectedByIntegrator( t, VAR, nIndexOfEvents );
   end
end
end


%=================================
end    % End of function Babyboot
%=================================
